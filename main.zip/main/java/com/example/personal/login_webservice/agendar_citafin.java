package com.example.personal.login_webservice;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.NotificationCompat;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class agendar_citafin extends AppCompatActivity implements Response.Listener<JSONObject>, Response.ErrorListener {
    TextView espe, fech, hor, doc, cod,pac;
    ProgressDialog progreso;
    Button regist, com;
    EditText ced;
    private NotificationManager notificacion;
    String estado = "Pendiente";
    int uno;
    StringRequest stringRequest;
    RequestQueue request;
    TextView esp;
    JsonObjectRequest jsonObjectRequest;
    int notificationID = 1;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agendar_citafin);
        try {


            espe = (TextView) findViewById(R.id.especialidad);
            fech = (TextView) findViewById(R.id.fecha);
            hor = (TextView) findViewById(R.id.horario);
            doc = (TextView) findViewById(R.id.doctor);
            pac = (TextView) findViewById(R.id.txt_pac);
            cod = (TextView) findViewById(R.id.cedulas);
            ced = (EditText) findViewById(R.id.cedula);
            esp = (TextView) findViewById(R.id.txt_esp);
            pac.setVisibility(View.GONE);
            esp.setVisibility(View.GONE);
            request = Volley.newRequestQueue(this);

            com = (Button) findViewById(R.id.comprobar);

            Bundle bundle = getIntent().getExtras();
            String esp = bundle.getString("ESPECIALIDAD");
            String fecha = bundle.getString("FECHA");
            String horario = bundle.getString("HORARIO");
            String doct = bundle.getString("DOCTOR");


            espe.setText(esp);
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        consultar_especialidad();
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, 2000);

            fech.setText(fecha);
            request = Volley.newRequestQueue(this);
            hor.setText(horario);
            doc.setText(doct);
            ced.setSingleLine(false);
            ced.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_SUBJECT);

            com.setOnClickListener(new View.OnClickListener() {
                @RequiresApi(api = Build.VERSION_CODES.M)
                @Override
                public void onClick(View view) {
                    try {

                        consultar_paciente();

                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    guardar_traumotologia();


                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }, 500);
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }


                    if (espe.getText().toString().equals("Cardiologia")) {
                        consultar_paciente();


                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    guardar_cardiologia();

                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }, 500);
                    }
                    if (espe.getText().toString().equals("Pediatria" + " ")) {
                        consultar_paciente();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    guardar_pediatria();

                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }, 500);
                    }
                    if (espe.getText().toString().equals("Ginecologia" + " ")) {
                        consultar_paciente();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    guardar_ginecologia();

                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }, 500);
                    }
                    if (espe.getText().toString().equals("Obstreticia" + " ")) {
                        consultar_paciente();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    guardar_obstreticia();

                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }, 500);
                    }
                    if (espe.getText().toString().equals("Cirugia Gen." + " ")) {
                        consultar_paciente();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    guardar_cirugiageneral();

                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }, 500);

                    }
                    if (espe.getText().toString().equals("Medicina Gener." + " ")) {
                        consultar_paciente();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {

                                    guardar_medicinalgeneral();

                                } catch (Exception e) {
                                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        }, 500);
                    }

                }
            });

            if (ActivityCompat.checkSelfPermission(agendar_citafin.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(agendar_citafin.this, Manifest
                    .permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(agendar_citafin.this, new String[]
                        {Manifest.permission.SEND_SMS,}, 1000);
            } else {

            }

        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
        ;

        // ATTENTION: This was auto-generated to implement the App Indexing API.
        // See https://g.co/AppIndexing/AndroidStudio for more information.
    }

    private void enviarMensaje(String numero, String mensaje, String msj) {
        try {

            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(numero, null, mensaje, null, null);

        } catch (Exception e) {

            e.printStackTrace();
        }

    }


    public void codigo() {
        uno = (int) Math.floor(Math.random() * 50000 + 10000);
        cod.setText(uno + "");
        String jhon = "5930960799906";

        enviarMensaje(jhon, String.valueOf(uno) + " este el  codigo de su cita, no olvide que es muy importante para gestionarla", "hola");
        displayNotification();

    }

    protected void displayNotification() {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("notificationID", notificationID);

        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, i, 0);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        CharSequence ticker = "Codigo de cita";
        CharSequence contentTitle = "Citas Medicas en Linea/MedicAPP";
        CharSequence contentText = "codigo de cita : " + cod.getText().toString() + " Revisa tu Bandeja de MSJ";
        Notification noti = new android.support.v7.app.NotificationCompat.Builder(this)
                .setContentIntent(pendingIntent)
                .setTicker(ticker)
                .setContentTitle(contentTitle)
                .setContentText(contentText)
                .setSmallIcon(R.drawable.kk)
                .addAction(R.drawable.kk, ticker, pendingIntent)
                .setVibrate(new long[]{100, 250, 100, 500})
                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                .build();
        nm.notify(notificationID, noti);
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    public void guardar_traumotologia() {
        if(ced.getText().toString().equals("")) {

            cedula();

        }else {

            codigo();


            String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha="+fech.getText().toString()+"&Horario="+hor.getText().toString()+"&Codigo="+cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
            url = url.replace(" ", "%20");

            try {
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();

                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void guardar_cardiologia() {



        if(ced.getText().toString().equals("")) {

          cedula();

        }else {
            try {
                codigo();
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();
                String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha=" + fech.getText().toString() + "&Horario=" + hor.getText().toString() + "&Codigo=" + cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
                url = url.replace(" ", "%20");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

    }

    public void guardar_pediatria() {
        if(ced.getText().toString().equals("")) {

            cedula();

        }else {
            codigo();

            try {
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();
                String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha=" + fech.getText().toString() + "&Horario=" + hor.getText().toString() + "&Codigo=" +cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
                  url = url.replace(" ", "%20");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void guardar_ginecologia() {
        if(ced.getText().toString().equals("")) {

            cedula();

        }else {
            codigo();

            try {
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();
                String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha=" + fech.getText().toString() + "&Horario=" + hor.getText().toString() + "&Codigo=" +cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
                    url = url.replace(" ", "%20");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void guardar_obstreticia() {
        if(ced.getText().toString().equals("")) {

            cedula();

        }else {
            codigo();

            try {
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();
                String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha=" + fech.getText().toString() + "&Horario=" + hor.getText().toString() + "&Codigo=" + cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
                 url = url.replace(" ", "%20");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

    }

    public void guardar_cirugiageneral() {
        if(ced.getText().toString().equals("")) {

            cedula();

        }else {
            codigo();

            try {
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();
                String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha=" + fech.getText().toString() + "&Horario=" + hor.getText().toString() + "&Codigo=" + cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
                   url = url.replace(" ", "%20");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }


    }

    public void guardar_medicinalgeneral() {
        if(ced.getText().toString().equals("")) {

            cedula();

        }else {
            codigo();

            try {
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();
                String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha=" + fech.getText().toString() + "&Horario=" + hor.getText().toString() + "&Codigo=" + cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
                       url = url.replace(" ", "%20");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void gestion_citas() {

        if(ced.getText().toString().equals("")) {

            cedula();

        }else {
            try {
                progreso = new ProgressDialog(this);
                progreso.setMessage("Cargando...");
                progreso.show();
                String url = "http://192.168.1.11/serviciosweb/registrarcita.php?Fecha=" + fech.getText().toString() + "&Horario=" + hor.getText().toString() + "&Codigo=" +cod.getText().toString() +"&Paciente=" + pac.getText().toString() + "&Especialidad=" + esp.getText().toString();
                  url = url.replace(" ", "%20");
                jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
                request.add(jsonObjectRequest);

            } catch (Exception exe) {
                Toast.makeText(this, exe.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }

    }


    @Override
    public void onResponse(JSONObject response) {
        try {
            citaagendada();
            progreso.hide();
            Intent intent = new Intent(getApplicationContext(), inicio.class);
            startActivity(intent);

        }catch (Exception e ){
            Toast.makeText(this,e.getMessage(), Toast.LENGTH_LONG).show();
        }


    }

    @Override
    public void onErrorResponse(VolleyError error) {
        progreso.hide();


        Log.i("ERROR", error.toString());

    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            //preventing default implementation previous to android.os.Build.VERSION_CODES.ECLAIR
            Intent intent = new Intent(getApplicationContext(), inicio.class);
            startActivity(intent);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }



    private void consultar_especialidad() {

        try {



            String url = "http://192.168.1.11/serviciosweb/consultar_especialidad.php?codigo=" + espe.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("especialidad");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_esp"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {

                        esp.setText(miUsuario.getEsp());


                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private void consultar_paciente() {

        try {



            String url = "http://192.168.1.11/serviciosweb/consultar_paciente.php?codigo=" + ced.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("paciente");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_pac"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {

                        pac.setText(miUsuario.getEsp());


                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }













    public void citaagendada() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast = inflater.inflate(R.layout.toas_personalizado, null);
        TextView txt = (TextView) customToast.findViewById(R.id.txttoas);
        txt.setText("Cita agendada, correctamente ");
        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }

    public void citanoagendada() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast = inflater.inflate(R.layout.toas_personalizado, null);
        TextView txt = (TextView) customToast.findViewById(R.id.txttoas);
        txt.setText("Error al agendar, Por Fabor Contacte con el administrador ");
        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }


    public void mensajeenviado() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast = inflater.inflate(R.layout.toas_personalizado, null);
        TextView txt = (TextView) customToast.findViewById(R.id.txttoas);
        txt.setText("Mensaje enviado");
        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }

    public void mensajenoenviado() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast = inflater.inflate(R.layout.toas_personalizado, null);
        TextView txt = (TextView) customToast.findViewById(R.id.txttoas);
        txt.setText("Mensaje no enviado");
        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }
    public void cedula() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast = inflater.inflate(R.layout.toas_personalizado, null);
        TextView txt = (TextView) customToast.findViewById(R.id.txttoas);
        txt.setText("Cedula es un campo obligatorio, Completelo!");
        Toast toast = new Toast(this);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }

}



