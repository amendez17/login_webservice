package com.example.personal.login_webservice;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.RingtoneManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class recupercontra extends AppCompatActivity {
    JsonObjectRequest jsonObjectRequest;
    RequestQueue request;
    EditText cedula, correo;
    int notificationID = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.activity_recupercontra);

            request = Volley.newRequestQueue(this);
            cedula = (EditText) findViewById(R.id.txt_cedula);
            correo = (EditText) findViewById(R.id.txt_correo);
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }


    }
    public void consular(View view){
        consultar_paciente();
    }

    private void consultar_paciente() {

        try {



            String url = "http://192.168.1.11/serviciosweb/recuperarcontrapac.php?codigo=" + cedula.getText().toString() +
                    "&contraseña=" + correo.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("paciente");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("contr_pac"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {

                        //pac.setText(miUsuario.getEsp());
                        Toast.makeText(getApplicationContext(), "Revisa la barra de notificaciones para ver tu contraseña", Toast.LENGTH_LONG).show();




                        //NOTIFICACION//////////////////////////////////////////////////
                        Intent i = new Intent(getApplicationContext(), recupercontra.class);
                        i.putExtra("notificationID", notificationID);

                        PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, i, 0);
                        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

                        CharSequence ticker = "Recuperación de contraseñas";
                        CharSequence contentTitle = "Citas Medicas en Linea/MedicAPP";
                        CharSequence contentText = "Contraseña : " + miUsuario.getEsp();
                        Notification noti = new android.support.v7.app.NotificationCompat.Builder(getApplicationContext())
                                .setContentIntent(pendingIntent)
                                .setTicker(ticker)
                                .setContentTitle(contentTitle)
                                .setContentText(contentText)
                                .setSmallIcon(R.drawable.kk)
                                .addAction(R.drawable.kk, ticker, pendingIntent)
                                .setVibrate(new long[]{100, 250, 100, 500})
                                .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
                                .build();
                        nm.notify(notificationID, noti);



                        ///////////////////////////////////////////////////////77

                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}
