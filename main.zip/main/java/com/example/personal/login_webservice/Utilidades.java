package com.example.personal.login_webservice;

/**
 * Created by Personal on 23/12/2017.
 */

public class Utilidades {

    public static final int LIST=1;
    public static final int GRID=2;

    public static int visualizacion=LIST;
}
