package com.example.personal.login_webservice;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Main2Activity extends AppCompatActivity {
    TextView et1, et2, et3, et4;
    String fecha, horario, esp, doct;
    ProgressDialog progreso;
    StringRequest stringRequest;
    Button val;
    String jhon;
    RequestQueue request;
    String respuesta;
    TextView especia;
    JsonObjectRequest jsonObjectRequest;
    TextView resp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ProgressDialog progreso;
        setContentView(R.layout.activity_main2);
        et1 = (TextView) findViewById(R.id.espprac);
        et2 = (TextView) findViewById(R.id.docpra);
        et3 = (TextView) findViewById(R.id.fechprac);
        et4 = (TextView) findViewById(R.id.horaprac);
        val = (Button) findViewById(R.id.veri);
        especia = (TextView)findViewById(R.id.txt_especialidad);
        resp = (TextView) findViewById(R.id.txt_respuesta);
        especia.setVisibility(View.GONE);
        resp.setVisibility(View.GONE);
        request = Volley.newRequestQueue(this);
        Bundle bundle = getIntent().getExtras();
        esp = bundle.getString("ESPECIALIDAD");
        fecha = bundle.getString("FECHA");
        horario = bundle.getString("HORARIO");
        doct = bundle.getString("DOCTOR");
        jhon = fecha;


        val.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et1.setText(esp);

                et2.setText(fecha);
                et3.setText(horario);
                et4.setText(doct);


                if (et1.getText().toString().equals("Traumotologia")) {
                    consultar_especialidad();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                veritraumo();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    },2000);




                }

                if (et1.getText().toString().equals("Cardiologia")) {
                    consultar_especialidad();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                vericardio();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    },1000);



                }
                if (et1.getText().toString().equals("Pediatria")) {
                    consultar_especialidad();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                veripedia();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    },1000);



                }
                if (et1.getText().toString().equals("Ginecologia")) {

                    consultar_especialidad();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                veriginec();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    },1000);



                }
                if (et1.getText().toString().equals("Obstreticia")) {
                    consultar_especialidad();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                veriobstre();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    },1000);


                }
                if (et1.getText().toString().equals("Cirugia Gen.")) {
                    consultar_especialidad();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                vericirugiagen();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    },1000);


                }
                if (et1.getText().toString().equals("Medicina Gener.")) {
                    consultar_especialidad();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                verimedicinagen();
                            }catch (Exception e){
                                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    },1000);


                }


            }
        });
    }


    private void veritraumo() {

        try {

            progreso = new ProgressDialog(this);
            progreso.setMessage("Ingresando...");
            progreso.show();


            String url = "http://192.168.1.11/serviciosweb/verificarcita.php?especialidad=" + especia.getText().toString() +
                    "&fecha=" + et2.getText().toString() +
                    "&hora=" + et3.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("cita");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_cit"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        progreso.hide();
                        resp.setText(miUsuario.getEsp());

                        if (!resp.getText().toString().equals("0")) {
                            progreso.hide();
                            Intent i = new Intent(getApplication(), agendarcita.class);
                            startActivity(i);
                            losentimos();

                        } else {
                            progreso.hide();
                            felicidades();
                            Intent i = new Intent(getApplication(), condiciones.class);
                            i.putExtra("ESPECIALIDAD", et1.getText().toString());
                            i.putExtra("FECHA", et3.getText().toString());
                            i.putExtra("HORARIO", et4.getText().toString());
                            i.putExtra("DOCTOR", et2.getText().toString());
                            startActivity(i);
                        }
                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private void vericardio() {

        try {

            progreso = new ProgressDialog(this);
            progreso.setMessage("Ingresando...");
            progreso.show();


            String url = "http://192.168.1.11/serviciosweb/verificarcita.php?especialidad=" + especia.getText().toString() +
                    "&fecha=" + et2.getText().toString() +
                    "&hora=" + et3.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("cita");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_cit"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        progreso.hide();
                        resp.setText(miUsuario.getEsp());

                        if (!resp.getText().toString().equals("0")) {
                            progreso.hide();
                            Intent i = new Intent(getApplication(), agendarcita.class);
                            startActivity(i);
                            losentimos();

                        } else {
                            progreso.hide();
                            felicidades();

                            Intent i = new Intent(getApplication(), condiciones.class);
                            i.putExtra("ESPECIALIDAD", et1.getText().toString());
                            i.putExtra("FECHA", et3.getText().toString());
                            i.putExtra("HORARIO", et4.getText().toString());
                            i.putExtra("DOCTOR", et2.getText().toString());
                            startActivity(i);
                        }
                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void veripedia() {

        try {

            progreso = new ProgressDialog(this);
            progreso.setMessage("Ingresando...");
            progreso.show();


            String url="http://192.168.1.11/serviciosweb/verificarcita.php?especialidad="+ especia.getText().toString() +
                    "&fecha=" + et2.getText().toString()+
                    "&hora=" + et3.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("cita");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_cit"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        progreso.hide();
                        resp.setText(miUsuario.getEsp());

                        if(!resp.getText().toString().equals("0")){
                            progreso.hide();
                            Intent i = new Intent(getApplication(), agendarcita.class);
                            startActivity(i);
                            losentimos();

                        }else{
                            progreso.hide();
                            felicidades();
                            Intent i = new Intent(getApplication(), condiciones.class);
                            i.putExtra("ESPECIALIDAD", et1.getText().toString());
                            i.putExtra("FECHA", et3.getText().toString());
                            i.putExtra("HORARIO", et4.getText().toString());
                            i.putExtra("DOCTOR", et2.getText().toString());
                            startActivity(i);
                        }
                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    private void veriginec() {

        try {

            progreso = new ProgressDialog(this);
            progreso.setMessage("Ingresando...");
            progreso.show();


            String url="http://192.168.1.11/serviciosweb/verificarcita.php?especialidad="+ especia.getText().toString() +
                    "&fecha=" + et2.getText().toString()+
                    "&hora=" + et3.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("cita");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_cit"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        progreso.hide();
                        resp.setText(miUsuario.getEsp());

                        if(!resp.getText().toString().equals("0")){
                            progreso.hide();
                            Intent i = new Intent(getApplication(), agendarcita.class);
                            startActivity(i);
                            losentimos();

                        }else{
                            progreso.hide();
                            felicidades();
                            Intent i = new Intent(getApplication(), condiciones.class);
                            i.putExtra("ESPECIALIDAD", et1.getText().toString());
                            i.putExtra("FECHA", et3.getText().toString());
                            i.putExtra("HORARIO", et4.getText().toString());
                            i.putExtra("DOCTOR", et2.getText().toString());
                            startActivity(i);
                        }
                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private void veriobstre() {

        try {

            progreso = new ProgressDialog(this);
            progreso.setMessage("Ingresando...");
            progreso.show();


            String url="http://192.168.1.11/serviciosweb/verificarcita.php?especialidad="+ especia.getText().toString() +
                    "&fecha=" + et2.getText().toString()+
                    "&hora=" + et3.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("cita");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_cit"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        progreso.hide();
                        resp.setText(miUsuario.getEsp());

                        if(!resp.getText().toString().equals("0")){
                            progreso.hide();
                            Intent i = new Intent(getApplication(), agendarcita.class);
                            startActivity(i);
                            losentimos();

                        }else{
                            progreso.hide();
                            felicidades();
                            Intent i = new Intent(getApplication(), condiciones.class);
                            i.putExtra("ESPECIALIDAD", et1.getText().toString());
                            i.putExtra("FECHA", et3.getText().toString());
                            i.putExtra("HORARIO", et4.getText().toString());
                            i.putExtra("DOCTOR", et2.getText().toString());
                            startActivity(i);
                        }
                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    private void vericirugiagen() {

        try {

            progreso = new ProgressDialog(this);
            progreso.setMessage("Ingresando...");
            progreso.show();


            String url="http://192.168.1.11/serviciosweb/verificarcita.php?especialidad="+ especia.getText().toString() +
                    "&fecha=" + et2.getText().toString()+
                    "&hora=" + et3.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("cita");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_cit"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        progreso.hide();
                        resp.setText(miUsuario.getEsp());

                        if(!resp.getText().toString().equals("0")){
                            progreso.hide();
                            Intent i = new Intent(getApplication(), agendarcita.class);
                            startActivity(i);
                            losentimos();

                        }else{
                            progreso.hide();
                            felicidades();
                            Intent i = new Intent(getApplication(), condiciones.class);
                            i.putExtra("ESPECIALIDAD", et1.getText().toString());
                            i.putExtra("FECHA", et3.getText().toString());
                            i.putExtra("HORARIO", et4.getText().toString());
                            i.putExtra("DOCTOR", et2.getText().toString());
                            startActivity(i);
                        }
                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void verimedicinagen() {

        try {

            progreso = new ProgressDialog(this);
            progreso.setMessage("Ingresando...");
            progreso.show();


            String url="http://192.168.1.11/serviciosweb/verificarcita.php?especialidad="+ especia.getText().toString() +
                    "&fecha=" + et2.getText().toString()+
                    "&hora=" + et3.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("cita");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_cit"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {
                        progreso.hide();
                        resp.setText(miUsuario.getEsp());

                        if(!resp.getText().toString().equals("0")){
                            progreso.hide();
                            Intent i = new Intent(getApplication(), agendarcita.class);
                            startActivity(i);
                            losentimos();

                        }else{
                            progreso.hide();
                            felicidades();
                            Intent i = new Intent(getApplication(), condiciones.class);
                            i.putExtra("ESPECIALIDAD", et1.getText().toString());
                            i.putExtra("FECHA", et3.getText().toString());
                            i.putExtra("HORARIO", et4.getText().toString());
                            i.putExtra("DOCTOR", et2.getText().toString());
                            startActivity(i);
                        }
                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }


    private void consultar_especialidad() {

        try {



            String url = "http://192.168.1.11/serviciosweb/consultar_especialidad.php?codigo=" + et1.getText().toString();
            jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {


                    Usuario miUsuario = new Usuario();

                    JSONArray json = response.optJSONArray("especialidad");
                    JSONObject jsonObject = null;

                    try {
                        jsonObject = json.getJSONObject(0);

                        miUsuario.setEsp(jsonObject.optString("cod_esp"));


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    try {

                        especia.setText(miUsuario.getEsp());


                        //SE MODIFICA
                    } catch (Exception e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
                    System.out.println();

                    Log.d("ERROR: ", error.toString());
                }
            });

            // request.add(jsonObjectRequest);
            VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
        } catch (Exception e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }




    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {


            //preventing default implementation previous to android.os.Build.VERSION_CODES.ECLAIR
            Intent intent = new Intent(getApplication(), agendarcita
                    .class);
            startActivity(intent);
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    public void losentimos(){
        LayoutInflater inflater= (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast=inflater.inflate(R.layout.toas_personalizado,null);
        TextView txt= (TextView)customToast.findViewById(R.id.txttoas);
        txt.setText("Lo sentimos, Esta cita ya fue agendada Anteriormente ");
        Toast toast =new Toast(this);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }

    public void felicidades(){
        LayoutInflater inflater= (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast=inflater.inflate(R.layout.toas_personalizado,null);
        TextView txt= (TextView)customToast.findViewById(R.id.txttoas);
        txt.setText("Felicidades, Cita Disponible ");
        Toast toast =new Toast(this);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }


}
