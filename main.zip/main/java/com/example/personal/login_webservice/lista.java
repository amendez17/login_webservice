package com.example.personal.login_webservice;

import android.app.ProgressDialog;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class lista extends AppCompatActivity  implements Response.Listener<JSONObject>,Response.ErrorListener{
    RecyclerView recyclerUsuarios;
    ArrayList<Usuario> listaUsuarios;
    ArrayList<Usuario> listauxiliar;
    private UsuariosAdapter adapter;
    EditText dni;
    Button gene;

    EditText busc;
    ProgressDialog progress;

    int wil;
    RecyclerView content;
    int height;
    ImageView un;



    // RequestQueue request;
    JsonObjectRequest jsonObjectRequest;
    RequestQueue request;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);
        try {

            dni  =  (EditText) findViewById(R.id.txt_consultar);
            adapter = new UsuariosAdapter(listaUsuarios, this);
            listaUsuarios = new ArrayList<>();
            listauxiliar = new ArrayList<>();
            gene = (Button)findViewById(R.id.boton_buscar);
            gene.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    cargarWebService();
                }
            });





            recyclerUsuarios = (RecyclerView) findViewById(R.id.idRecycler);
            busc = (EditText) findViewById(R.id.txtbuscar);

            recyclerUsuarios.setLayoutManager(new LinearLayoutManager(this));
            recyclerUsuarios.setHasFixedSize(true);



//permiso al sd
      /*  if (ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions((Activity) getContext(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,}, 1000);
        } else {
        }*/


            final UsuariosAdapter adapter = new UsuariosAdapter(listauxiliar, this);
            recyclerUsuarios.setAdapter(adapter);


            busc.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    coger(s.toString());

                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });
        }catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }

    }



    private void cargarWebService() {

        progress = new ProgressDialog(this);
        progress.setMessage("Consultando...");
        progress.show();


        String url = "http://192.168.1.11/serviciosweb/citas_paciente.php?codigo=" + dni.getText().toString();

        jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
        // request.add(jsonObjectRequest);
        VolleySingleton.getIntanciaVolley(this).addToRequestQueue(jsonObjectRequest);
    }


    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(this, "No se puede conectar " + error.toString(), Toast.LENGTH_LONG).show();
        System.out.println();
        Log.d("ERROR: ", error.toString());
        progress.hide();
    }

    @Override
    public void onResponse(JSONObject response) {
        Usuario usuario = null;

        JSONArray json = response.optJSONArray("usuario");

        try {

            for (int i = 0; i < json.length(); i++) {
                usuario = new Usuario();
                JSONObject jsonObject = null;
                jsonObject = json.getJSONObject(i);

                usuario.setNombres(jsonObject.optString("NOM_ESP"));
                usuario.setAsignacion(jsonObject.optString("FEC_CIT"));
                usuario.setCedula(jsonObject.optString("HOR_CIT"));

                listaUsuarios.add(usuario);
                listauxiliar.add(usuario);
            }
            listas();
            progress.hide();





        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "No se ha podido establecer conexión con el servidor" +
                    " " + response, Toast.LENGTH_LONG).show();
            progress.hide();
        }

    }

    public void coger(String texto) {

        listaUsuarios.clear();
        for (int i = 0; i < listauxiliar.size(); i++) {

            if (listauxiliar.get(i).getNombres().toLowerCase().contains(texto.toLowerCase())) {

                listaUsuarios.add(listauxiliar.get(i));
            }
        }
        adapter.notifyDataSetChanged();
    }


    //.........................................................................................

    /*public void tela (){ // create a new document
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)

        {
            PdfDocument document = new PdfDocument();

            getScreenshotFromRecyclerView(recyclerUsuarios);
            content = recyclerUsuarios;
            content.setBackgroundColor(Color.parseColor("#303030"));


            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(wil, height, 1).create();

            // create a new page from the PageInfo
            PdfDocument.Page page = document.startPage(pageInfo);

            // repaint the user's text into the page
            content.draw(page.getCanvas());

            // do final processing of the page
            document.finishPage(page);

            // saving pdf document to sdcard
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy - HH-mm-ss",Locale.getDefault());
            String pdfName = "Revisões_"
                    + sdf.format(Calendar.getInstance().getTime()) + ".pdf";

            // all created files will be saved at path /sdcard/PDFDemo_AndroidSRC/
            File outputFile = new File(Environment.getExternalStorageDirectory().getPath(), pdfName);


            String targetPdf = "/sdcard/test.pdf";
            File filePath = new File(targetPdf);
            try {
                document.writeTo(new FileOutputStream(filePath));
                Toast.makeText(getContext(), "Done", Toast.LENGTH_LONG).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getContext(), "Something wrong: " + e.toString(),
                        Toast.LENGTH_LONG).show();
            }

            // close the document
            document.close();
        }
    }


    public void getScreenshotFromRecyclerView(RecyclerView view) {
        RecyclerView.Adapter adapter = view.getAdapter();
        if (adapter != null) {
            int size = adapter.getItemCount();

            for (int i = 0; i < size; i++) {
                RecyclerView.ViewHolder holder = adapter.createViewHolder(view, adapter.getItemViewType(i));
                adapter.onBindViewHolder(holder, i);
                holder.itemView.measure(View.MeasureSpec.makeMeasureSpec(view.getWidth(), View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
                holder.itemView.layout(0, 0, holder.itemView.getMeasuredWidth(), holder.itemView.getMeasuredHeight());
                height += holder.itemView.getMeasuredHeight();
            }
            wil=view.getMeasuredWidth();


        }

    }*/


    //......................................................................................

    public void  listas(){
        LayoutInflater inflater= (LayoutInflater)this.getSystemService(LAYOUT_INFLATER_SERVICE);
        View customToast=inflater.inflate(R.layout.toas_personalizado,null);
        TextView txt= (TextView)customToast.findViewById(R.id.txttoas);
        txt.setText("Richard, esta son todas las citas anuladas actualmente");
        Toast toast =new Toast(this);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.setView(customToast);
        toast.show();
    }

}
